package server.accounts;

/**
 * @GitHub : https://github.com/zacscoding
 */
public enum AccountRole {

    ADMIN, USER
}
